package com.example.moviess

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
