import 'package:flutter/material.dart';
import 'package:movies_app/core/constants/app_assets.dart';
import 'package:movies_app/core/constants/app_colors.dart';
import 'package:movies_app/core/constants/app_routes.dart';
import 'package:movies_app/model/custom_widget_model/buttons_model.dart';
import 'package:movies_app/model/custom_widget_model/textfield_model.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      body: SafeArea(
        child: Column(
        children: [
          SizedBox(height: 40,),
          buildAppLogo(),
          SizedBox(height:20),
          buildEmailField(),
          SizedBox(height:10),
          buildPasswordField(),
          SizedBox(height:10),
          buildForgotPassword(),
          SizedBox(height:35),
          buildLoginButton(),
          SizedBox(height:15),
          buildCreateAccountRow(),
          SizedBox(height:25),
          buildORRow(),
          SizedBox(height:35),
          buildLoginWithGoogle(),
          SizedBox(height:10),
          buildToggleButton(),
        ]),
      ),
    );
  }

  Widget buildAppLogo()=>Image.asset(AppAssets.logo);

  Widget buildEmailField()=>CustomTextField(label: "Email",prefixIcon: Icon(Icons.email));

  Widget buildPasswordField()=>CustomTextField(label: "Password",prefixIcon: Icon(Icons.lock),suffixIcon: Icon(Icons.visibility_off,color: Colors.white,),isPassword: true,);

  Widget buildForgotPassword() => Padding(
    padding: const EdgeInsets.symmetric(horizontal: 20),
    child: Row(
      mainAxisAlignment: MainAxisAlignment.end,
      children: [

        InkWell(
          onTap: () {
  // Navigator.push(context, AppRoutes.forgotPassword());
  },
         child:Text("Forget Password ?",style:TextStyle(fontWeight:FontWeight.w400,fontSize: 18,color: AppColors.yellow,fontStyle: FontStyle.italic),
        ),),
      ],
    ),
  );

  Widget buildLoginButton()=>CustomButton(
      text: "Login",
      bgColor:AppColors.yellow ,
      textColor: Colors.black,
      onPressed: (){},
  );

  Widget buildCreateAccountRow() => Row(
    mainAxisAlignment: MainAxisAlignment.center,
    children: [
      Text(
        "Don’t Have Account ? ",
        style: TextStyle(fontSize: 18, color: Colors.white),
      ),
      InkWell(
        onTap: () {
          Navigator.push(context, AppRoutes.register());
        },
        child: Text(
          "Create One",
          style: TextStyle(
            fontSize: 20,
            fontWeight: FontWeight.bold,
            color: AppColors.yellow,
          ),
        ),
      ),
    ],
  );


  Widget buildORRow()=>Row(
    children: [
      SizedBox(width: 60),
      Expanded(child: Divider(color: AppColors.yellow, thickness: 2)),
      Padding(
        padding: EdgeInsets.symmetric(horizontal: 12),
        child: Text("OR", style: TextStyle(color: AppColors.yellow,fontSize: 16,fontFamily: "Roboto")),
      ),
      Expanded(child: Divider(color: AppColors.yellow, thickness: 2)),
      SizedBox(width: 60),
    ],
  );

  Widget buildLoginWithGoogle()=>CustomButton(text: "Login With Google", bgColor: AppColors.yellow, textColor: Colors.black,
  onPressed: (){},
  );

  Widget buildToggleButton()=>Container();
}