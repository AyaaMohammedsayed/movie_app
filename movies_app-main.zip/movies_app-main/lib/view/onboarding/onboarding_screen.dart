import 'package:flutter/material.dart';
import 'package:introduction_screen/introduction_screen.dart';
import 'package:movies_app/core/constants/app_colors.dart';
import 'package:movies_app/core/constants/app_routes.dart';
import '../../viewmodel/onboarding_viewmodel.dart';

class OnboardingScreen extends StatelessWidget {
  const OnboardingScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final viewModel = OnboardingViewModel();
    final introKey = GlobalKey<IntroductionScreenState>();

    return Scaffold(
      body: IntroductionScreen(
        key: introKey,
        globalBackgroundColor: Colors.black,
        pages: viewModel.onboardingPages.asMap().entries.map((entry) {
          final index = entry.key;
          final page = entry.value;
          final isFirst = index == 0;
          final isLast = index == viewModel.onboardingPages.length - 1;

          return PageViewModel(
            titleWidget: const SizedBox.shrink(),
            bodyWidget: Container(
              padding: const EdgeInsets.all(18),
              decoration: const BoxDecoration(
                color: Colors.black87,
                borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Text(
                    page.title,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 22,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 12),
                  if (page.description.isNotEmpty)
                    Text(
                      page.description,
                      textAlign: TextAlign.center,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 16,
                      ),
                    ),
                  const SizedBox(height: 24),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      // Next button
                      SizedBox(
                        height: 50,
                        child: OutlinedButton(
                          onPressed: () {
                            if (isLast) {
                              Navigator.push(context, AppRoutes.login());
                            } else {
                              introKey.currentState?.next();
                            }
                          },
                          style: OutlinedButton.styleFrom(
                            backgroundColor:AppColors.yellow,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12),
                            ),
                            side: BorderSide(color: AppColors.yellow),
                          ),
                          child: Text(
                            isLast
                                ? 'Finish'
                                : isFirst
                                ? 'Explore Now'
                                : 'Next',
                            style: TextStyle(
                              color: Colors.black,
                              fontSize: 18,
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(height: 10),
                      // Back button
                      if (!isFirst && index != 1)
                        SizedBox(
                          height: 50,
                          child: OutlinedButton(
                            onPressed: () {
                              introKey.currentState?.previous();
                            },
                            style: OutlinedButton.styleFrom(
                            backgroundColor:isFirst || index == 1 ? AppColors.yellow : Colors.black,
                            shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(12),
                              ),
                              side: BorderSide(color: AppColors.yellow),
                            ),
                            child: Text(
                              'Back',
                              style: TextStyle(color: AppColors.yellow, fontSize: 18),
                            ),
                          ),
                        ),
                    ],
                  ),
                ],
              ),
            ),
            image: Image.asset(page.image, fit: BoxFit.cover),
            decoration: const PageDecoration(
              contentMargin: EdgeInsets.zero,
              imageFlex: 3,
              bodyFlex: 2,
              bodyAlignment: Alignment.bottomCenter,
              imageAlignment: Alignment.topCenter,
              fullScreen: true,
            ),
          );
        }).toList(),
        showNextButton: false,
        showSkipButton: false,
        showDoneButton: false,
        dotsDecorator: DotsDecorator(
          activeColor: AppColors.yellow,
          color: Colors.grey,
          size: Size(3, 4),
          activeSize: Size(13, 8),
          activeShape: RoundedRectangleBorder(
            borderRadius: BorderRadius.all(Radius.circular(24)),
          ),
        ),
      ),
    );
  }
}
