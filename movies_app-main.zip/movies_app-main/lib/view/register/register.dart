import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:movies_app/core/constants/app_colors.dart';
import 'package:movies_app/model/custom_widget_model/buttons_model.dart';
import 'package:movies_app/model/custom_widget_model/text_buttons_model.dart';
import 'package:movies_app/model/custom_widget_model/textfield_model.dart';

class RegisterScreen extends StatefulWidget {
  const RegisterScreen({super.key});

  @override
  State<RegisterScreen> createState() => _RegisterScreenState();
}

class _RegisterScreenState extends State<RegisterScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      appBar: AppBar(
        backgroundColor: AppColors.black,
        title: Text("Register",style:TextStyle(color: AppColors.yellow,fontSize: 18),),
        centerTitle: true,
        leading: IconButton(onPressed: (){Navigator.pop(context);}, icon:Icon( Icons.arrow_back,color: AppColors.yellow,))
      ),
      body: Column(
        children: [
          buildSelectAvatar(),
          SizedBox(height: 20,),
          buildNameField(),
          buildEmailField(),
          buildPasswordField(),
          buildConfirmPasswordField(),
          buildPhoneNumberField(),
          SizedBox(height: 40,),
          buildCreateAccountButton(),
          buildAlreadyHaveAccountRow(),
        ],
      ),
    );
  }
  Widget buildSelectAvatar()=>Container(
    height: 150,);
  Widget buildNameField()=>CustomTextField(label:"Name",prefixIcon: Icon(Icons.person,color: Colors.white,), );
  Widget buildEmailField()=>CustomTextField(label:"Email",prefixIcon: Icon(Icons.email,color: Colors.white,), );
  Widget buildPasswordField()=>CustomTextField(label:"Password",prefixIcon: Icon(Icons.lock,color: Colors.white,),isPassword: true, );
  Widget buildConfirmPasswordField()=>CustomTextField(label:"Confirm Password",prefixIcon: Icon(Icons.lock,color: Colors.white,),isPassword: true, );
  Widget buildPhoneNumberField()=>CustomTextField(label:"Phone Number",prefixIcon: Icon(Icons.phone,color: Colors.white,),inputFormatters: [FilteringTextInputFormatter.digitsOnly,LengthLimitingTextInputFormatter(11),], );
  Widget buildCreateAccountButton()=>CustomButton(text: "Create Account", bgColor: AppColors.yellow, textColor: Colors.black,onPressed: (){
    ///go to login if account created
  },);
  Widget buildAlreadyHaveAccountRow()=>Row(
    mainAxisAlignment: MainAxisAlignment.center,
    children: [
      CustomTextButtons(text: "Login",hint: "Already Have Account ?", onPressed: (){}, textStyle: TextStyle(color: AppColors.yellow)),
    ],
  );
}
