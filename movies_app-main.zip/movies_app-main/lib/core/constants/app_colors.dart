
import 'dart:ui';

class AppColors {
  static Color black =Color(0xFF121312);
  static Color grey =Color(0xFF282A28);
  static Color white =Color(0xFFFFFFFF);
  static Color oliveGray=Color(0xFF282A28);
  static Color yellow=Color(0xFFF6BD00);
  static Color green=Color(0xFF57AA53);
  static Color red=Color(0xFFE82626);
}