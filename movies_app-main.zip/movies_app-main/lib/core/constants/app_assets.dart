abstract final class AppAssets {
  ///Images
  static const _baseImage = "assets/images/";
  static const logo = "${_baseImage}logo.png";
  static const userA = "${_baseImage}gamer1.png";
  static const onBoarding1 = "${_baseImage}onboarding1.png";
  static const onBoarding2 = "${_baseImage}onboarding2.png";
  static const onBoarding3 = "${_baseImage}onboarding3.png";
  static const onBoarding4 = "${_baseImage}onboarding4.png";
  static const onBoarding5 = "${_baseImage}onboarding5.png";
  static const onBoarding6 = "${_baseImage}onboarding6.png";

  ///Icons
  static const _baseIcon="assets/icons/";
  static const emailIcon="${_baseIcon}email.png";
  static const arIcon="${_baseIcon}ar.png";
  static const enIcon="${_baseIcon}en.png";
  static const hideIcon="${_baseIcon}hide.png";
  static const nameIcon="${_baseIcon}name.png";
  static const passIcon="${_baseIcon}password.png";
  static const phoneIcon="${_baseIcon}phone.png";

}