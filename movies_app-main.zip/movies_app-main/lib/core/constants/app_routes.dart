import 'package:flutter/material.dart';
import 'package:movies_app/view/onboarding/onboarding_screen.dart';
import 'package:movies_app/view/register/register.dart';
import '../../view/login/login_screen.dart';

abstract final class AppRoutes {
  static Route onboarding() => MaterialPageRoute(builder: (_) => OnboardingScreen());
  static Route login() => MaterialPageRoute(builder: (_) => LoginScreen());
  static Route register() => MaterialPageRoute(builder: (_) => RegisterScreen());
}
