import 'package:flutter/material.dart';

class CustomButton extends StatefulWidget {
  final String text;
  final Color bgColor;
  final Color textColor;
  final BorderSide? side;
  final Function()? onPressed;

  const CustomButton({
    super.key,
    required this.text,
    required this.bgColor,
    required this.textColor,
    this.side,
    this.onPressed,
  });

  @override
  State<CustomButton> createState() => _CustomButtonState();
}

class _CustomButtonState extends State<CustomButton> {
  @override
  Widget build(BuildContext context) {
    return ElevatedButton(
      onPressed: widget.onPressed,
      style: ElevatedButton.styleFrom(
        backgroundColor: widget.bgColor,
        foregroundColor: widget.textColor,
        padding: EdgeInsets.all(15),
        minimumSize: Size(392, 50),
        elevation: 0,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
          side: widget.side ?? BorderSide.none,
        ),
      ),
      child: Text(widget.text,style: TextStyle(fontSize: 20),),
    );
  }
}
