import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../../core/constants/app_colors.dart';

class CustomTextField extends StatefulWidget {
  final Widget? prefixIcon;
  final Widget? suffixIcon;
  final String label;
  final TextEditingController? controller;
  final bool isPassword;
  final String? hint;
  final int? minlines;
  final int? maxlines;
  final FloatingLabelBehavior? floatingLabelBehavior;
  final TextInputType? keyboardType;
  final TextInputAction? textInputAction;
  final bool readOnly;
  final Function(String)? onChanged;
  final VoidCallback? onTap;
  final List<TextInputFormatter>? inputFormatters;///to control the input

  const CustomTextField({
    super.key,
    required this.label,
    this.controller,
    this.prefixIcon,
    this.suffixIcon,
    this.isPassword = false,
    this.hint,
    this.minlines,
    this.maxlines,
    this.floatingLabelBehavior,
    this.keyboardType,
    this.textInputAction,
    this.readOnly = false,
    this.onChanged,
    this.onTap,
    this.inputFormatters
  });

  @override
  State<CustomTextField> createState() => _CustomTextFieldState();
}

class _CustomTextFieldState extends State<CustomTextField> {
  late bool obscure;
  final OutlineInputBorder defaultBorder = OutlineInputBorder(
    borderRadius: BorderRadius.all(Radius.circular(15)),
    borderSide: BorderSide(color: AppColors.grey),
  );

  @override
  void initState() {
    super.initState();
    obscure = widget.isPassword;
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(left: 20, right: 20, top: 20),
      child: SizedBox(
        width: double.infinity,
        child: TextField(
          style: const TextStyle(color: Colors.white),
          minLines: widget.minlines,
          maxLines: widget.maxlines ?? (widget.isPassword ? 1 : null),
          controller: widget.controller,
          keyboardType: widget.keyboardType,
          textInputAction: widget.textInputAction,
          readOnly: widget.readOnly,
          onChanged: widget.onChanged,
          onTap: widget.onTap,
          inputFormatters: widget.inputFormatters,
          decoration: InputDecoration(
            hintText: widget.hint,
            hintStyle: const TextStyle(color: Colors.white60),
            fillColor: AppColors.grey,
            filled: true,
            floatingLabelBehavior: widget.floatingLabelBehavior,
            prefixIcon: widget.prefixIcon,
            prefixIconColor: Colors.white,
            suffixIcon: widget.isPassword
                ? InkWell(
              onTap: () {
                setState(() {
                  obscure = !obscure;
                });
              },
              child: Icon(
                obscure ? Icons.visibility_off : Icons.visibility,
                color: Colors.white,
              ),
            )
                : widget.suffixIcon,
            suffixIconColor: Theme.of(context).colorScheme.secondary,
            label: Text(
              widget.label,
              style: const TextStyle(color: Colors.white, fontSize: 18),
            ),
            enabledBorder: defaultBorder,
            focusedBorder: defaultBorder.copyWith(
              borderSide: BorderSide(color: AppColors.grey, width: 2),
            ),
            border: defaultBorder,
          ),
          obscureText: widget.isPassword ? obscure : false,
        ),
      ),
    );
  }
}
