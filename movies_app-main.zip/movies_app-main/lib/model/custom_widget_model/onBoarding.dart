import 'package:flutter/material.dart';

class CustomTextButtons extends StatefulWidget {
  final String? hint;
  final String text;
  final Alignment? align;
  final TextStyle textStyle;
  final Function()? onPressed;
  const CustomTextButtons({
    super.key,
    required this.text,
    this.hint,
    this.align,
    required this.onPressed,
    required this.textStyle,
  });

  @override
  State<CustomTextButtons> createState() => _CustomTextButtonsState();
}

class _CustomTextButtonsState extends State<CustomTextButtons> {
  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        if (widget.hint != null)
          Text(
            widget.hint!,
            style: TextStyle(color: Colors.white, fontSize: 16),
          ),
        TextButton(
          onPressed: () {},
          style: TextButton.styleFrom(alignment: widget.align),
          child: Text(widget.text, style: widget.textStyle),
        ),
      ],
    );
  }
}
