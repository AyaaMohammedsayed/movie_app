import 'package:flutter/material.dart';

import 'package:movies_app/view/splash/splash.dart';
import 'core/constants/app_colors.dart';

void main() {
  runApp(const MyApp());
}
class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Movies',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
        scaffoldBackgroundColor: AppColors.black

      ),
      home: Splash(),
      debugShowCheckedModeBanner: false,
    );
  }
}
